# 🤖 Telegram Monitor Bot

Bot theo dõi nhiều nhóm Telegram và gửi cảnh báo khi **User B không trả lời tin nhắn của User A** trong thời hạn quy định.

## ⏱ Logic thời gian

| Khung giờ | Timeout |
|-----------|---------|
| 12:30 – 18:00 | **5 phút** (giờ bận) |
| 18:00 – 12:30 hôm sau | **60 phút** (giờ rảnh) |

---

## 🚀 Hướng dẫn cài đặt

### 1. Yêu cầu
- Python **3.11+**
- Tài khoản Telegram thật (để đăng nhập Telethon)
- Bot Telegram nhận thông báo (tạo qua [@BotFather](https://t.me/BotFather))

### 2. Cài thư viện

```powershell
python -m venv venv
venv\Scripts\activate        # Windows
# hoặc: source venv/bin/activate  (Linux/Mac)
pip install -r requirements.txt
```

### 3. Cấu hình

```powershell
copy .env.example .env
```

Mở file `.env` và điền đầy đủ thông tin:

| Biến | Mô tả |
|------|-------|
| `API_ID` / `API_HASH` | Lấy tại https://my.telegram.org/apps |
| `SESSION_NAME` | Tên file session (tự đặt) |
| `NOTIFY_BOT_TOKEN` | Token bot nhận thông báo (từ @BotFather) |
| `NOTIFY_CHAT_ID` | Chat ID nhận thông báo (dùng [@userinfobot](https://t.me/userinfobot)) |
| `USER_A_IDS` | ID các User A, phân cách phẩy |
| `USER_B_IDS` | ID các User B, phân cách phẩy |
| `MONITOR_GROUP_IDS` | ID các group cần theo dõi, phân cách phẩy |
| `PEAK_START` / `PEAK_END` | Khung giờ bận (mặc định `12:30` / `18:00`) |
| `PEAK_TIMEOUT_MINUTES` | Timeout giờ bận (phút, mặc định `5`) |
| `OFF_TIMEOUT_MINUTES` | Timeout giờ rảnh (phút, mặc định `60`) |
| `TIMEZONE` | Múi giờ (mặc định `Asia/Ho_Chi_Minh`) |

> 💡 **Lấy User ID / Group ID**: Thêm bot [@userinfobot](https://t.me/userinfobot) hoặc [@getidsbot](https://t.me/getidsbot) vào group, gõ `/start` để lấy ID.

### 4. Chạy bot

```powershell
python main.py
```

Lần đầu chạy, Telethon sẽ yêu cầu:
1. Nhập **số điện thoại** Telegram (kèm mã quốc gia, vd: `+84912345678`)
2. Nhập **mã OTP** gửi về Telegram
3. (Nếu có 2FA) Nhập **mật khẩu Cloud Password**

Session sẽ được lưu vào file `<SESSION_NAME>.session` — **các lần sau không cần đăng nhập lại**.

---

## 📁 Cấu trúc file

```
telegram_monitor_bot/
├── main.py          # Điểm khởi động
├── config.py        # Tải cấu hình từ .env
├── monitor.py       # Logic theo dõi & phát hiện timeout
├── notifier.py      # Gửi thông báo qua Telegram Bot API
├── requirements.txt # Danh sách thư viện
├── .env.example     # Template cấu hình (copy thành .env)
└── README.md        # Hướng dẫn này
```

---

## 🔔 Mẫu thông báo

```
⚠️ CẢNH BÁO CHƯA TRẢ LỜI

📌 Nhóm: Nhóm Kinh Doanh (-1001234567890)
👤 User A: Nguyễn Văn A (111111111)
📩 Nội dung: Anh ơi cho em hỏi sản phẩm X còn không ạ?
🕐 Gửi lúc: 03/03/2026 14:32:15
⏳ Đã chờ: 5 phút (giới hạn 5 phút)

🔔 User B chưa phản hồi tin nhắn này!
```

---

## ⚙️ Test nhanh (rút ngắn timeout)

Trong `.env`, tạm thời đặt:
```
PEAK_TIMEOUT_MINUTES=1
OFF_TIMEOUT_MINUTES=2
```
Sau khi test xong, khôi phục lại giá trị thật.

---

## ❓ Troubleshooting

| Lỗi | Giải pháp |
|-----|-----------|
| `API_ID và API_HASH bắt buộc` | Điền đúng trong `.env` |
| `PhoneNumberBannedError` | Dùng tài khoản Telegram khác |
| Bot không nhận được group messages | Đảm bảo tài khoản đã join group, và `MONITOR_GROUP_IDS` đúng |
| `NOTIFY_CHAT_ID` không nhận được tin | Gửi `/start` cho bot thông báo trước |
