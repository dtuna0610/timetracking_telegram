"""
config.py — Tải cấu hình từ file .env
"""
import os
from datetime import time
from dotenv import load_dotenv
import pytz

load_dotenv()

# ── Telegram API (Telethon UserClient) ─────────────────────────────────────
API_ID: int = int(os.getenv("API_ID", "0"))
API_HASH: str = os.getenv("API_HASH", "")
SESSION_NAME: str = os.getenv("SESSION_NAME", "monitor_session")

# ── Bot gửi thông báo ───────────────────────────────────────────────────────
NOTIFY_BOT_TOKEN: str = os.getenv("NOTIFY_BOT_TOKEN", "")
NOTIFY_CHAT_ID: str = os.getenv("NOTIFY_CHAT_ID", "")

# ── Danh sách user và group ─────────────────────────────────────────────────
def _parse_ids(env_key: str) -> list[int]:
    raw = os.getenv(env_key, "")
    return [int(x.strip()) for x in raw.split(",") if x.strip()]

USER_A_IDS: list[int] = _parse_ids("USER_A_IDS")
USER_B_IDS: list[int] = _parse_ids("USER_B_IDS")
MONITOR_GROUP_IDS: list[int] = _parse_ids("MONITOR_GROUP_IDS")

# ── Khung giờ & timeout ─────────────────────────────────────────────────────
def _parse_time(env_key: str, default: str) -> time:
    raw = os.getenv(env_key, default)
    h, m = map(int, raw.split(":"))
    return time(h, m)

PEAK_START: time = _parse_time("PEAK_START", "12:30")
PEAK_END: time   = _parse_time("PEAK_END",   "18:00")

PEAK_TIMEOUT_MINUTES: int = int(os.getenv("PEAK_TIMEOUT_MINUTES", "5"))
OFF_TIMEOUT_MINUTES: int  = int(os.getenv("OFF_TIMEOUT_MINUTES",  "60"))

# ── Timezone ────────────────────────────────────────────────────────────────
TIMEZONE = pytz.timezone(os.getenv("TIMEZONE", "Asia/Ho_Chi_Minh"))

# ── Validation ──────────────────────────────────────────────────────────────
def validate():
    errors = []
    if not API_ID or not API_HASH:
        errors.append("API_ID và API_HASH bắt buộc phải có (lấy tại https://my.telegram.org/apps)")
    if not NOTIFY_BOT_TOKEN:
        errors.append("NOTIFY_BOT_TOKEN bắt buộc (tạo bot qua @BotFather)")
    if not NOTIFY_CHAT_ID:
        errors.append("NOTIFY_CHAT_ID bắt buộc")
    if not USER_A_IDS:
        errors.append("USER_A_IDS bắt buộc (danh sách user A)")
    if not USER_B_IDS:
        errors.append("USER_B_IDS bắt buộc (danh sách user B)")
    if not MONITOR_GROUP_IDS:
        errors.append("MONITOR_GROUP_IDS bắt buộc (danh sách group cần theo dõi)")
    if errors:
        raise EnvironmentError("❌ Lỗi cấu hình .env:\n" + "\n".join(f"  - {e}" for e in errors))
