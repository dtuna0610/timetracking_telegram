"""
notifier.py — Gửi thông báo đến Telegram Bot
"""
import aiohttp
import logging
from datetime import datetime
import config

logger = logging.getLogger(__name__)

TELEGRAM_API_URL = "https://api.telegram.org/bot{token}/sendMessage"


async def send_alert(
    group_title: str,
    group_id: int,
    user_a_name: str,
    user_a_id: int,
    message_text: str,
    sent_at: datetime,
    waited_minutes: float,
    timeout_minutes: int,
):
    """Gửi thông báo cảnh báo đến chat Telegram đã cấu hình."""
    waited_str = _format_duration(waited_minutes)
    sent_at_local = sent_at.astimezone(config.TIMEZONE)
    sent_at_str = sent_at_local.strftime("%d/%m/%Y %H:%M:%S")

    text = (
        f"⚠️ <b>CẢNH BÁO CHƯA TRẢ LỜI</b>\n\n"
        f"📌 <b>Nhóm:</b> {_escape(group_title)} (<code>{group_id}</code>)\n"
        f"👤 <b>User A:</b> {_escape(user_a_name)} (<code>{user_a_id}</code>)\n"
        f"📩 <b>Nội dung:</b> {_escape(message_text[:200])}\n"
        f"🕐 <b>Gửi lúc:</b> {sent_at_str}\n"
        f"⏳ <b>Đã chờ:</b> {waited_str} (giới hạn {timeout_minutes} phút)\n\n"
        f"🔔 User B chưa phản hồi tin nhắn này!"
    )

    url = TELEGRAM_API_URL.format(token=config.NOTIFY_BOT_TOKEN)
    payload = {
        "chat_id": config.NOTIFY_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status != 200:
                    body = await resp.text()
                    logger.error(f"Telegram API lỗi {resp.status}: {body}")
                else:
                    logger.info(f"✅ Đã gửi thông báo cho group {group_id}, user {user_a_id}")
    except Exception as e:
        logger.error(f"Không gửi được thông báo: {e}")


def _format_duration(minutes: float) -> str:
    if minutes < 60:
        return f"{int(minutes)} phút"
    h = int(minutes // 60)
    m = int(minutes % 60)
    return f"{h} giờ {m} phút" if m else f"{h} giờ"


def _escape(text: str) -> str:
    """Escape HTML đặc biệt cho Telegram parse_mode HTML."""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
