"""
monitor.py — Logic theo dõi tin nhắn và phát hiện chưa trả lời
"""
import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import pytz
from telethon import TelegramClient, events
from telethon.tl.types import User, Chat, Channel

import config
import notifier

logger = logging.getLogger(__name__)


@dataclass
class PendingMessage:
    """Lưu trạng thái một tin nhắn của User A chưa được User B trả lời."""
    message_id: int
    group_id: int
    group_title: str
    user_a_id: int
    user_a_name: str
    message_text: str
    sent_at: datetime          # UTC
    timeout_minutes: int
    notified: bool = False     # Đã gửi thông báo rồi chưa


# Kho lưu tin nhắn đang chờ trả lời
# key: "{group_id}:{message_id}"
_pending: dict[str, PendingMessage] = {}


# ── Helper: xác định timeout theo giờ hiện tại ──────────────────────────────

def _get_timeout_minutes(now_local: datetime) -> int:
    """
    Trả về số phút timeout dựa vào giờ local hiện tại:
    - 12:30 ≤ now < 18:00  →  PEAK_TIMEOUT_MINUTES (mặc định 5 phút)
    - ngoài khung giờ trên  →  OFF_TIMEOUT_MINUTES  (mặc định 60 phút)
    """
    t = now_local.time().replace(second=0, microsecond=0)
    if config.PEAK_START <= t < config.PEAK_END:
        return config.PEAK_TIMEOUT_MINUTES
    return config.OFF_TIMEOUT_MINUTES


def _now_local() -> datetime:
    return datetime.now(config.TIMEZONE)


def _display_name(user: Optional[User]) -> str:
    if user is None:
        return "Unknown"
    parts = [user.first_name or "", user.last_name or ""]
    name = " ".join(p for p in parts if p).strip()
    return name or str(user.id)


# ── Xử lý tin nhắn mới ──────────────────────────────────────────────────────

def register_handlers(client: TelegramClient):
    """Đăng ký event handlers cho Telethon client."""

    @client.on(events.NewMessage(chats=config.MONITOR_GROUP_IDS))
    async def on_message(event: events.NewMessage.Event):
        sender = await event.get_sender()
        chat   = await event.get_chat()

        if not isinstance(sender, User):
            return  # Bỏ qua bot hoặc channel message

        sender_id  = sender.id
        group_id   = event.chat_id
        group_title = getattr(chat, "title", str(group_id))
        msg_text   = event.message.message or ""
        msg_id     = event.message.id

        now_local = _now_local()

        # ── User B trả lời: xóa TẤT CẢ pending trong group này ────────────
        if sender_id in config.USER_B_IDS:
            removed = [k for k in list(_pending.keys()) if _pending[k].group_id == group_id]
            for k in removed:
                del _pending[k]
            if removed:
                logger.info(
                    f"[{group_title}] User B ({sender_id}) đã trả lời → xóa {len(removed)} pending"
                )
            return

        # ── User A nhắn: thêm vào pending ──────────────────────────────────
        if sender_id in config.USER_A_IDS:
            timeout = _get_timeout_minutes(now_local)
            key = f"{group_id}:{msg_id}"
            _pending[key] = PendingMessage(
                message_id    = msg_id,
                group_id      = group_id,
                group_title   = group_title,
                user_a_id     = sender_id,
                user_a_name   = _display_name(sender),
                message_text  = msg_text,
                sent_at       = datetime.now(timezone.utc),
                timeout_minutes = timeout,
            )
            logger.info(
                f"[{group_title}] User A ({sender_id}) nhắn tin | timeout={timeout}p | key={key}"
            )


# ── Vòng lặp kiểm tra định kỳ ───────────────────────────────────────────────

async def check_pending_loop():
    """Chạy mỗi 30 giây, kiểm tra các tin nhắn quá timeout và gửi cảnh báo."""
    logger.info("🔄 Bắt đầu vòng lặp kiểm tra pending messages (interval=30s)")
    while True:
        await asyncio.sleep(30)
        now_utc   = datetime.now(timezone.utc)
        now_local = _now_local()

        for key, pending in list(_pending.items()):
            if pending.notified:
                continue

            elapsed_minutes = (now_utc - pending.sent_at).total_seconds() / 60

            if elapsed_minutes >= pending.timeout_minutes:
                logger.info(
                    f"⏰ Timeout! [{pending.group_title}] User A={pending.user_a_id} "
                    f"({elapsed_minutes:.1f}/{pending.timeout_minutes}p) → gửi thông báo"
                )
                await notifier.send_alert(
                    group_title     = pending.group_title,
                    group_id        = pending.group_id,
                    user_a_name     = pending.user_a_name,
                    user_a_id       = pending.user_a_id,
                    message_text    = pending.message_text,
                    sent_at         = pending.sent_at,
                    waited_minutes  = elapsed_minutes,
                    timeout_minutes = pending.timeout_minutes,
                )
                pending.notified = True
