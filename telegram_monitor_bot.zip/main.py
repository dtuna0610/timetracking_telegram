"""
main.py — Điểm khởi động của Telegram Monitor Bot
"""
import asyncio
import logging
import sys

from telethon import TelegramClient

import config
import monitor

# ── Logging ─────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("bot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("main")


async def main():
    # Kiểm tra cấu hình trước khi khởi động
    try:
        config.validate()
    except EnvironmentError as e:
        logger.error(str(e))
        sys.exit(1)

    logger.info("=" * 60)
    logger.info("🤖 Telegram Monitor Bot đang khởi động...")
    logger.info(f"   Theo dõi {len(config.MONITOR_GROUP_IDS)} group(s)")
    logger.info(f"   User A: {config.USER_A_IDS}")
    logger.info(f"   User B: {config.USER_B_IDS}")
    logger.info(f"   Khung giờ bận: {config.PEAK_START}–{config.PEAK_END}")
    logger.info(f"   Timeout bận:   {config.PEAK_TIMEOUT_MINUTES} phút")
    logger.info(f"   Timeout rảnh:  {config.OFF_TIMEOUT_MINUTES} phút")
    logger.info("=" * 60)

    client = TelegramClient(
        config.SESSION_NAME,
        config.API_ID,
        config.API_HASH,
    )

    # Đăng ký event handlers
    monitor.register_handlers(client)

    async with client:
        me = await client.get_me()
        logger.info(f"✅ Đã đăng nhập với tài khoản: {me.first_name} (id={me.id})")

        # Chạy vòng lặp kiểm tra song song
        await asyncio.gather(
            client.run_until_disconnected(),
            monitor.check_pending_loop(),
        )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Bot đã dừng lại.")
